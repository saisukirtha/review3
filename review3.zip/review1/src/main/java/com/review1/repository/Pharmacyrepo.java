package com.review1.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.review1.model.Pharmacymodel;
public interface Pharmacyrepo extends JpaRepository<Pharmacymodel,Integer> {
	@Query("select s from Pharmacymodel s where s.producttype=?1 and s.name=?2")
    public List<Pharmacymodel> getStudentsByProducttype(String producttype,String name);
   //named parameter
   @Query("select s from Pharmacymodel s where s.name=:name")
   public List<Pharmacymodel> getStudentsByName(String name);
	//DML
	@Modifying
	@Query("delete from Pharmacymodel s where s.name=?1")
	public int deleteStudentByName(String name);
   @Modifying
   @Query("update Pharmacymodel s set s.producttype=?1 where s.name=?2")
   public int updateStudentByProducttype(String producttype,String name);
} 
