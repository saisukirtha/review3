package com.review1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Review1Application {

	public static void main(String[] args) {
		SpringApplication.run(Review1Application.class, args);
	}

}
